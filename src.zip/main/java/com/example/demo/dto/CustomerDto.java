package com.example.demo.dto;

public interface CustomerDto {

    public String getNguoiNhan();

    public Double getTongTien();

    public Double getSoLuongDon();
}
