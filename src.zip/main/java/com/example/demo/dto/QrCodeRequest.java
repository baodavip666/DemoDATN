package com.example.demo.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QrCodeRequest {

    private String image;

    private Integer idSpct;
}
