package com.example.demo.service.admin;

import com.example.demo.entity.HinhAnh;

public interface HinhAnhService {

    String create(HinhAnh hinhAnh);

}
