package com.example.demo.controller.user;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/user")
public class ChiTietSanPhamController {
//    @GetMapping(value = "/san-pham-chi-tiet")
//    public String SanPhamChiTiet() {
//        return "user/chi-tiet-san-pham/chitietsanpham";
//    }
}
